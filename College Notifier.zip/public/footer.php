</div>
<!-- <footer class="page-footer font-small blue bg-secondary text-white mt-5 w-100">
  <div class="footer-copyright text-center py-3">© 2021 Copyright:
    Vishnu Vinod
  </div>
</footer> -->

<!-- Bootstrap Js -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous">
</script>
<script src="/jsLibs/jquery-toast-plugin-master/dist/jquery.toast.min.js"></script>
<script src="/jsLibs/HoldOnSpinner/HoldOn.min.js"></script>
<script src="/public/js/isMobile.js"></script>

<script type="text/javascript">
let tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
let tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl)
})
</script>

</body>

</html>